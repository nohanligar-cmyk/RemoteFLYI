package com.example

import com.example.protocol.NexendPacket
import com.example.protocol.NexendPacketParser
import com.example.protocol.NexendProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NexendProtocolUnitTest {

    @Test
    fun `test packet build and CRC16 calculation`() {
        val payload = byteArrayOf(0x01, 0x02, 0x03, 0x04)
        val packetBytes = NexendProtocol.buildPacket(
            msgId = NexendProtocol.MSG_HEARTBEAT,
            seq = 42.toByte(),
            payload = payload
        )

        // Header (2) + MsgId (1) + Seq (1) + Len (1) + Payload (4) + CRC (2) = 11 bytes
        assertEquals(11, packetBytes.size)
        assertEquals(NexendProtocol.SYNC_1, packetBytes[0])
        assertEquals(NexendProtocol.SYNC_2, packetBytes[1])
        assertEquals(NexendProtocol.MSG_HEARTBEAT, packetBytes[2])
        assertEquals(42.toByte(), packetBytes[3])
        assertEquals(4.toByte(), packetBytes[4])
    }

    @Test
    fun `test packet parser successfully parses valid packet`() {
        var parsedPacket: NexendPacket? = null
        val parser = NexendPacketParser(
            onPacketReceived = { packet ->
                parsedPacket = packet
            }
        )

        val payload = byteArrayOf(0x10, 0x20, 0x30)
        val rawData = NexendProtocol.buildPacket(
            msgId = NexendProtocol.MSG_TELEMETRY,
            seq = 5.toByte(),
            payload = payload
        )

        parser.parseBytes(rawData)

        assertNotNull(parsedPacket)
        assertEquals(NexendProtocol.MSG_TELEMETRY, parsedPacket?.msgId)
        assertEquals(5, parsedPacket?.sequence)
        assertEquals(3, parsedPacket?.payload?.size)
        assertEquals(1, parser.totalPacketsReceived)
        assertEquals(0, parser.totalChecksumErrors)
    }

    @Test
    fun `test packet parser rejects corrupted CRC`() {
        var parsedPacket: NexendPacket? = null
        val parser = NexendPacketParser(
            onPacketReceived = { packet -> parsedPacket = packet }
        )

        val payload = byteArrayOf(0x0A, 0x0B)
        val rawData = NexendProtocol.buildPacket(
            msgId = NexendProtocol.MSG_BATTERY,
            seq = 1.toByte(),
            payload = payload
        )

        // Corrupt one payload byte
        rawData[5] = 0xFF.toByte()

        parser.parseBytes(rawData)

        assertEquals(null, parsedPacket)
        assertEquals(0, parser.totalPacketsReceived)
        assertEquals(1, parser.totalChecksumErrors)
    }
}
