package com.example.model

enum class FlightMode(val displayName: String) {
    NA("N/A"),
    MANUAL("MANUAL"),
    STABILIZE("STABILIZE"),
    ALT_HOLD("ALT-HOLD"),
    POS_HOLD("P-GPS"),
    RTH("RTH"),
    ACRO("ACRO"),
    FAILSAFE("FAILSAFE")
}

enum class ArmingState(val label: String) {
    DISARMED("DISARMED"),
    ARMING_REQUESTED("ARMING..."),
    ARMED("ARMED"),
    PREARM_BLOCKED("PRE-ARM BLOCKED")
}

data class BatteryTelemetry(
    val voltage: Float = 0.0f,
    val currentAmps: Float = 0.0f,
    val remainingPercent: Int = 0,
    val consumedMah: Int = 0,
    val cellCount: Int = 4,
    val cellVoltages: List<Float> = emptyList(),
    val isLowBattery: Boolean = false,
    val isCriticalBattery: Boolean = false,
    val isValid: Boolean = false,
    val lastUpdateMs: Long = 0L
) {
    val estimatedFlightMinutes: Int
        get() = if (isValid && remainingPercent > 0) (remainingPercent * 0.25f).toInt() else 0
}

data class GpsTelemetry(
    val hasFix: Boolean = false,
    val fixType: String = "NO FIX",
    val satellites: Int = 0,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val altitudeMeters: Float = 0.0f,
    val hdop: Float = 99.9f,
    val distanceToHomeMeters: Float = 0.0f,
    val homeLatitude: Double = 0.0,
    val homeLongitude: Double = 0.0,
    val isHomeSet: Boolean = false,
    val isValid: Boolean = false,
    val lastUpdateMs: Long = 0L
)

data class ImuTelemetry(
    val rollDeg: Float = 0.0f,
    val pitchDeg: Float = 0.0f,
    val yawDeg: Float = 0.0f,
    val gyroXDegPerSec: Float = 0.0f,
    val gyroYDegPerSec: Float = 0.0f,
    val gyroZDegPerSec: Float = 0.0f,
    val accelXG: Float = 0.0f,
    val accelYG: Float = 0.0f,
    val accelZG: Float = 1.0f,
    val isCalibrated: Boolean = false,
    val isValid: Boolean = false,
    val lastUpdateMs: Long = 0L
)

data class BaroTelemetry(
    val altitudeMeters: Float = 0.0f,
    val verticalSpeedMs: Float = 0.0f,
    val pressureHpa: Float = 1013.25f,
    val temperatureCelsius: Float = 25.0f,
    val isValid: Boolean = false,
    val lastUpdateMs: Long = 0L
)

data class ToFTelemetry(
    val distanceCm: Int = 0,
    val isValid: Boolean = false,
    val isOutOfRange: Boolean = false,
    val lastUpdateMs: Long = 0L
)

data class OpticalFlowTelemetry(
    val motionX: Float = 0.0f,
    val motionY: Float = 0.0f,
    val surfaceQuality: Int = 0,
    val isValid: Boolean = false
)

data class SensorHealth(
    val imuDetected: Boolean = false,
    val imuHealthy: Boolean = false,
    val baroDetected: Boolean = false,
    val baroHealthy: Boolean = false,
    val magDetected: Boolean = false,
    val magHealthy: Boolean = false,
    val gpsDetected: Boolean = false,
    val gpsHealthy: Boolean = false,
    val tofDetected: Boolean = false,
    val tofHealthy: Boolean = false,
    val opticalFlowDetected: Boolean = false,
    val opticalFlowHealthy: Boolean = false
) {
    val allEssentialHealthy: Boolean
        get() = imuHealthy && baroHealthy
}

data class RcTelemetry(
    val isConnected: Boolean = false,
    val throttlePercent: Int = 0,
    val rollStickPercent: Int = 0,
    val pitchStickPercent: Int = 0,
    val yawStickPercent: Int = 0,
    val switchA: Int = 0, // Arm switch
    val switchB: Int = 0, // Mode switch
    val switchC: Int = 0, // RTH switch
    val switchD: Int = 0, // Aux
    val rssiDbm: Int = -120,
    val packetLossPercent: Float = 0.0f,
    val latencyMs: Int = 0,
    val heartbeatIntervalMs: Long = 0L,
    val firmwareVersion: String = "ESP32-C3 v1.0.4",
    val lastUpdateMs: Long = 0L
)

data class FcStatus(
    val isConnected: Boolean = false,
    val armingState: ArmingState = ArmingState.DISARMED,
    val flightMode: FlightMode = FlightMode.NA,
    val failsafeTriggered: Boolean = false,
    val loopTimeUs: Int = 250, // 4kHz loop
    val cpuLoadPercent: Int = 18,
    val firmwareVersion: String = "NEXEND-FC-RP2040 v2.1.0",
    val protocolVersion: String = "NX-PROTO 1.4",
    val flightTimeSeconds: Long = 0L,
    val horizontalSpeedMs: Float = 0.0f,
    val lastUpdateMs: Long = 0L
)

data class PidParameters(
    val rollP: Float = 45.0f,
    val rollI: Float = 70.0f,
    val rollD: Float = 32.0f,
    val pitchP: Float = 48.0f,
    val pitchI: Float = 75.0f,
    val pitchD: Float = 35.0f,
    val yawP: Float = 40.0f,
    val yawI: Float = 60.0f,
    val yawD: Float = 0.0f,
    val rcRate: Float = 1.0f,
    val superRate: Float = 0.70f,
    val rcExpo: Float = 0.15f,
    val isSyncedWithFc: Boolean = false,
    val isDirty: Boolean = false
)

data class VideoFeedStats(
    val isReceiving: Boolean = false,
    val format: String = "N/A", // MJPEG, YUY2, N/A
    val resolutionWidth: Int = 0,
    val resolutionHeight: Int = 0,
    val fps: Int = 0,
    val bitrateKbps: Int = 0,
    val droppedFrames: Int = 0,
    val decoderLatencyMs: Int = 0,
    val receiverModel: String = "ROTG01 / ROTG02 USB FPV",
    val lastFrameTimestampMs: Long = 0L
)

enum class LogSeverity {
    INFO,
    WARN,
    ERROR,
    CRITICAL
}

data class FlightLogEntry(
    val id: Long = System.currentTimeMillis(),
    val timestampMs: Long = System.currentTimeMillis(),
    val severity: LogSeverity = LogSeverity.INFO,
    val category: String, // "USB", "FC", "RC", "VIDEO", "SAFETY"
    val message: String,
    val details: String? = null
)
