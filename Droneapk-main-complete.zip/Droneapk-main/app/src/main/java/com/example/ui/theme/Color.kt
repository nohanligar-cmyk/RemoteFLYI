package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NEXEND Brand & Aviation Palette
val NexendDarkBackground = Color(0xFF090D12)
val NexendDarkSurface = Color(0xFF131922)
val NexendCardSurface = Color(0xCC1B222D)
val NexendCardBorder = Color(0x334E5D6C)
val NexendGlassOverlay = Color(0x800D131C)

val NexendCyanPrimary = Color(0xFF00E5FF)
val NexendCyanSecondary = Color(0xFF00B0FF)
val NexendAccentGold = Color(0xFFFFB300)

val AviationRed = Color(0xFFE53935)
val AviationRedBg = Color(0xE6D32F2F)
val AviationGreen = Color(0xFF00E676)
val AviationGreenBg = Color(0x3300E676)
val AviationAmber = Color(0xFFFF9100)
val AviationAmberBg = Color(0x33FF9100)

val NexendTextPrimary = Color(0xFFFFFFFF)
val NexendTextSecondary = Color(0xFFB0BEC5)
val NexendTextMuted = Color(0xFF78909C)
val NexendTextDisabled = Color(0xFF455A64)

val NexendOsdBackground = Color(0x66000000)
val NexendOsdText = Color(0xFFEEEEEE)
val NexendOsdHighlight = Color(0xFF00E5FF)
