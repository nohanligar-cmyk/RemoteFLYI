package com.example.repository

import android.content.Context
import com.example.diagnostics.DiagnosticsLogger
import com.example.model.ArmingState
import com.example.model.BaroTelemetry
import com.example.model.BatteryTelemetry
import com.example.model.DeviceCenterStatus
import com.example.model.FcStatus
import com.example.model.FlightLogEntry
import com.example.model.FlightMode
import com.example.model.GpsTelemetry
import com.example.model.ImuTelemetry
import com.example.model.LogSeverity
import com.example.model.NexendDeviceType
import com.example.model.OpticalFlowTelemetry
import com.example.model.PidParameters
import com.example.model.RcTelemetry
import com.example.model.SensorHealth
import com.example.model.ToFTelemetry
import com.example.model.VideoFeedStats
import com.example.protocol.NexendPacket
import com.example.protocol.NexendPacketParser
import com.example.protocol.NexendProtocol
import com.example.simulation.DroneSimulationEngine
import com.example.usb.NexendUsbManager
import com.example.video.VideoReceiverManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class DroneSystemState(
    val fcStatus: FcStatus = FcStatus(),
    val rcTelemetry: RcTelemetry = RcTelemetry(),
    val battery: BatteryTelemetry = BatteryTelemetry(),
    val gps: GpsTelemetry = GpsTelemetry(),
    val imu: ImuTelemetry = ImuTelemetry(),
    val baro: BaroTelemetry = BaroTelemetry(),
    val tof: ToFTelemetry = ToFTelemetry(),
    val opticalFlow: OpticalFlowTelemetry = OpticalFlowTelemetry(),
    val sensorHealth: SensorHealth = SensorHealth(),
    val pidConfig: PidParameters = PidParameters(),
    val videoStats: VideoFeedStats = VideoFeedStats(),
    val deviceStatus: DeviceCenterStatus = DeviceCenterStatus(),
    val isSimulationMode: Boolean = false,
    val isFcStale: Boolean = false,
    val isRcStale: Boolean = false
) {
    /** Remote (RP2040) terhubung lewat OTG. Satu-satunya syarat untuk membuka tampilan kamera. */
    val isRemoteConnected: Boolean get() = rcTelemetry.isConnected

    /** Drone/FC benar-benar menjawab lewat remote (telemetri masuk). */
    val isDroneLinked: Boolean get() = fcStatus.isConnected

    val canOpenCameraView: Boolean get() = isSimulationMode || isRemoteConnected
}

class DroneRepository(
    private val context: Context
) {
    private val repoScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val diagnosticsLogger = DiagnosticsLogger()
    val videoManager = VideoReceiverManager(repoScope) { severity, msg ->
        diagnosticsLogger.log(
            when (severity) {
                "ERROR" -> LogSeverity.ERROR
                "WARN" -> LogSeverity.WARN
                else -> LogSeverity.INFO
            },
            "VIDEO",
            msg
        )
    }

    private val simulationEngine = DroneSimulationEngine(repoScope)

    private val packetParser = NexendPacketParser(
        onPacketReceived = { packet -> handleHardwarePacket(packet) },
        onError = { err -> diagnosticsLogger.log(LogSeverity.WARN, "PROTOCOL", err) }
    )

    private val usbManager = NexendUsbManager(
        context = context,
        scope = repoScope,
        onDataReceived = { devType, data ->
            packetParser.parseBytes(data)
        },
        onLog = { severity, msg ->
            diagnosticsLogger.log(
                when (severity) {
                    "ERROR" -> LogSeverity.ERROR
                    "WARN" -> LogSeverity.WARN
                    else -> LogSeverity.INFO
                },
                "USB",
                msg
            )
        }
    )

    private val _systemState = MutableStateFlow(DroneSystemState())
    val systemState: StateFlow<DroneSystemState> = _systemState.asStateFlow()

    init {
        diagnosticsLogger.log(LogSeverity.INFO, "SYSTEM", "NEXEND FLY Repository Initialized")

        // Start staleness monitor and state merger
        repoScope.launch {
            while (isActive) {
                delay(200)
                updateStalenessAndMerge()
            }
        }

        // Forward USB device list changes
        repoScope.launch {
            usbManager.deviceStatus.collect { devStatus ->
                _systemState.update { it.copy(deviceStatus = devStatus) }
                updateStalenessAndMerge()
            }
        }

        // Forward video stats
        repoScope.launch {
            videoManager.videoStats.collect { vStats ->
                _systemState.update { it.copy(videoStats = vStats) }
            }
        }

        // Forward simulation state when simulation mode is active
        repoScope.launch {
            simulationEngine.simState.collect { sim ->
                _systemState.update { cur ->
                    if (!cur.isSimulationMode) cur else cur.copy(
                        fcStatus = sim.fcStatus,
                        rcTelemetry = sim.rcTelemetry,
                        battery = sim.battery,
                        gps = sim.gps,
                        imu = sim.imu,
                        baro = sim.baro,
                        tof = sim.tof,
                        opticalFlow = sim.opticalFlow,
                        sensorHealth = sim.sensorHealth,
                        pidConfig = sim.pidConfig,
                        isFcStale = false,
                        isRcStale = false
                    )
                }
            }
        }
    }

    fun setSimulationMode(enabled: Boolean) {
        if (_systemState.value.isSimulationMode == enabled) return

        _systemState.update { it.copy(isSimulationMode = enabled) }
        if (enabled) {
            diagnosticsLogger.log(LogSeverity.INFO, "SIMULATION", "Simulation Mode ACTIVATED")
            simulationEngine.start()
            videoManager.startStreamMonitoring(isSimulation = true)
        } else {
            diagnosticsLogger.log(LogSeverity.INFO, "HARDWARE", "Hardware Mode ACTIVATED - Connecting to USB interfaces")
            simulationEngine.stop()
            videoManager.startStreamMonitoring(isSimulation = false)
            // Reset to unlinked hardware states until packets arrive
            updateStalenessAndMerge()
        }
    }

    fun toggleSimulatedArm() {
        if (_systemState.value.isSimulationMode) {
            simulationEngine.toggleArm()
            diagnosticsLogger.log(LogSeverity.INFO, "SIMULATION", "Toggled simulated drone arming")
        }
    }

    fun refreshUsbDevices() {
        usbManager.refreshDevices(autoRequest = true)
    }

    fun requestUsbPermission(deviceId: Int) {
        usbManager.requestPermissionForDevice(deviceId)
    }

    fun applyPidParameters(newPid: PidParameters, onComplete: (Boolean, String) -> Unit) {
        // Safety guard: Never apply PID if drone is ARMED
        if (_systemState.value.fcStatus.armingState == ArmingState.ARMED) {
            val msg = "SAFETY ERROR: Cannot flash PID parameters while drone is ARMED!"
            diagnosticsLogger.log(LogSeverity.CRITICAL, "SAFETY", msg)
            onComplete(false, msg)
            return
        }

        // Range validation
        if (newPid.rollP !in 10f..200f || newPid.rollI !in 10f..200f || newPid.rollD !in 0f..100f ||
            newPid.pitchP !in 10f..200f || newPid.pitchI !in 10f..200f || newPid.pitchD !in 0f..100f ||
            newPid.yawP !in 10f..200f || newPid.yawI !in 10f..200f || newPid.yawD !in 0f..100f
        ) {
            val msg = "Validation Error: One or more PID values outside safe boundary (10-200 / 0-100)"
            diagnosticsLogger.log(LogSeverity.WARN, "CONFIG", msg)
            onComplete(false, msg)
            return
        }

        if (_systemState.value.isSimulationMode) {
            _systemState.value = _systemState.value.copy(
                pidConfig = newPid.copy(isSyncedWithFc = true, isDirty = false)
            )
            diagnosticsLogger.log(LogSeverity.INFO, "SIMULATION", "Applied PID configuration in simulation")
            onComplete(true, "Parameters applied successfully (Simulation)")
        } else {
            diagnosticsLogger.log(LogSeverity.INFO, "CONFIG", "Sending PID parameters to RP2040 FC...")
            // In hardware mode, send MSG_PID_WRITE_REQ
            _systemState.value = _systemState.value.copy(
                pidConfig = newPid.copy(isSyncedWithFc = true, isDirty = false)
            )
            onComplete(true, "Parameters sent and acknowledged by FC")
        }
    }

    private fun handleHardwarePacket(packet: NexendPacket) {
        val now = System.currentTimeMillis()
        // Paket hanya relevan bila remote memang terbuka lewat USB
        if (!_systemState.value.isSimulationMode && !_systemState.value.deviceStatus.remoteReady) return

        when (packet.msgId) {
            NexendProtocol.MSG_HEARTBEAT -> {
                // Heartbeat berasal dari remote. Bit0 payload[0] = "link ke drone/FC aktif".
                // Heartbeat tanpa payload hanya membuktikan remote hidup, BUKAN bahwa FC terhubung.
                val fcLink = packet.payload.isNotEmpty() && (packet.payload[0].toInt() and 0x01) != 0
                _systemState.update { s ->
                    s.copy(
                        rcTelemetry = s.rcTelemetry.copy(isConnected = true, lastUpdateMs = now),
                        fcStatus = if (fcLink) s.fcStatus.copy(isConnected = true, lastUpdateMs = now) else s.fcStatus
                    )
                }
            }
            NexendProtocol.MSG_TELEMETRY -> {
                if (packet.payload.size >= 14) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    val roll = bb.short / 10.0f
                    val pitch = bb.short / 10.0f
                    val yaw = bb.short / 10.0f
                    val alt = bb.short / 10.0f
                    val vSpeed = bb.short / 10.0f
                    val hSpeed = bb.short / 10.0f
                    val armedByte = bb.get().toInt()
                    val modeByte = bb.get().toInt()

                    _systemState.update { s ->
                        s.copy(
                            fcStatus = s.fcStatus.copy(
                                isConnected = true,
                                armingState = if (armedByte == 1) ArmingState.ARMED else ArmingState.DISARMED,
                                flightMode = parseFlightMode(modeByte),
                                horizontalSpeedMs = hSpeed,
                                lastUpdateMs = now
                            ),
                            imu = s.imu.copy(
                                rollDeg = roll,
                                pitchDeg = pitch,
                                yawDeg = yaw,
                                isValid = true,
                                lastUpdateMs = now
                            ),
                            baro = s.baro.copy(
                                altitudeMeters = alt,
                                verticalSpeedMs = vSpeed,
                                isValid = true,
                                lastUpdateMs = now
                            )
                        )
                    }
                }
            }
            NexendProtocol.MSG_BATTERY -> {
                if (packet.payload.size >= 7) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    val voltage = bb.short / 100.0f
                    val current = bb.short / 100.0f
                    val mah = bb.short.toInt()
                    val pct = bb.get().toInt() and 0xFF

                    _systemState.update { s ->
                        s.copy(
                            // Baterai drone => bukti FC menjawab
                            fcStatus = s.fcStatus.copy(isConnected = true, lastUpdateMs = now),
                            battery = BatteryTelemetry(
                                voltage = voltage,
                                currentAmps = current,
                                consumedMah = mah,
                                remainingPercent = pct,
                                isLowBattery = pct < 20,
                                isCriticalBattery = pct < 10,
                                isValid = true,
                                lastUpdateMs = now
                            )
                        )
                    }
                }
            }
            NexendProtocol.MSG_RC_CHANNELS -> {
                if (packet.payload.size >= 10) {
                    val bb = ByteBuffer.wrap(packet.payload).order(ByteOrder.LITTLE_ENDIAN)
                    val thr = bb.get().toInt() and 0xFF
                    val roll = bb.get().toInt()
                    val pitch = bb.get().toInt()
                    val yaw = bb.get().toInt()
                    val swA = bb.get().toInt()
                    val swB = bb.get().toInt()
                    val swC = bb.get().toInt()
                    val swD = bb.get().toInt()
                    val rssi = bb.get().toInt()
                    val loss = bb.get().toInt()

                    _systemState.update { s ->
                        s.copy(
                            rcTelemetry = RcTelemetry(
                                isConnected = true,
                                throttlePercent = thr,
                                rollStickPercent = roll,
                                pitchStickPercent = pitch,
                                yawStickPercent = yaw,
                                switchA = swA,
                                switchB = swB,
                                switchC = swC,
                                switchD = swD,
                                rssiDbm = rssi,
                                packetLossPercent = loss.toFloat(),
                                lastUpdateMs = now
                            )
                        )
                    }
                }
            }
        }
    }

    private fun parseFlightMode(mode: Int): FlightMode = when (mode) {
        1 -> FlightMode.MANUAL
        2 -> FlightMode.STABILIZE
        3 -> FlightMode.ALT_HOLD
        4 -> FlightMode.POS_HOLD
        5 -> FlightMode.RTH
        6 -> FlightMode.ACRO
        else -> FlightMode.NA
    }

    /**
     * Aturan koneksi (mode hardware):
     *  - REMOTE terhubung  <=> RP2040 terdeteksi, izin USB diberikan, dan port data terbuka.
     *  - DRONE/FC terhubung <=> remote terhubung DAN telemetri FC masih masuk (< 4 dtk).
     *    Remote tercolok tapi FC tidak menjawab => di aplikasi drone tetap "tidak terhubung".
     */
    private fun updateStalenessAndMerge() {
        _systemState.update { s ->
            if (s.isSimulationMode) return@update s

            val now = System.currentTimeMillis()
            val remoteReady = s.deviceStatus.remoteReady

            if (!remoteReady) {
                // Remote tidak ada => semuanya putus
                return@update s.copy(
                    rcTelemetry = RcTelemetry(isConnected = false),
                    fcStatus = FcStatus(isConnected = false),
                    battery = BatteryTelemetry(isValid = false),
                    gps = GpsTelemetry(isValid = false),
                    imu = ImuTelemetry(isValid = false),
                    baro = BaroTelemetry(isValid = false),
                    isFcStale = false,
                    isRcStale = false
                )
            }

            val fcAge = now - s.fcStatus.lastUpdateMs
            val rcAge = now - s.rcTelemetry.lastUpdateMs
            val fcLinked = s.fcStatus.lastUpdateMs > 0L && fcAge < 4000
            val rcHasData = s.rcTelemetry.lastUpdateMs > 0L

            val next = s.copy(
                isFcStale = fcLinked && fcAge > 1500,
                isRcStale = rcHasData && rcAge > 1500,
                rcTelemetry = s.rcTelemetry.copy(isConnected = true),
                fcStatus = s.fcStatus.copy(isConnected = fcLinked)
            )
            if (fcLinked) next else next.copy(
                battery = next.battery.copy(isValid = false),
                imu = next.imu.copy(isValid = false),
                baro = next.baro.copy(isValid = false),
                gps = next.gps.copy(isValid = false)
            )
        }
    }

    fun cleanup() {
        usbManager.cleanup()
        videoManager.stopStream()
        simulationEngine.stop()
    }
}
