package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.FlightLiveViewScreen
import com.example.ui.screens.HomeDashboardScreen
import com.example.ui.sheets.ConnectionGuideDialog
import com.example.ui.sheets.DeviceCenterSheet
import com.example.ui.sheets.FcCenterSheet
import com.example.ui.sheets.FlightLogsSheet
import com.example.ui.sheets.PidConfigSheet
import com.example.ui.sheets.RemoteCenterSheet
import com.example.ui.sheets.SensorCenterSheet
import com.example.ui.sheets.SettingsSheet
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.ActiveScreen
import com.example.viewmodel.ActiveSheet
import com.example.viewmodel.DroneViewModel

class MainActivity : ComponentActivity() {
    private val droneViewModel: DroneViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                NexendFlyApp(viewModel = droneViewModel)
            }
        }
    }

    // Dipanggil (launchMode=singleTop) saat remote dicolok dan Android membuka aplikasi ini lagi
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        droneViewModel.onUsbIntent()
    }

    override fun onResume() {
        super.onResume()
        // Pulang dari dialog izin USB / sistem: pindai ulang agar status langsung terbarui
        droneViewModel.onUsbIntent()
    }
}

@Composable
fun NexendFlyApp(viewModel: DroneViewModel = viewModel()) {
    val context = LocalContext.current
    val systemState by viewModel.systemState.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val activeSheet by viewModel.activeSheet.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    // Handle toast messages
    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.clearToast()
        }
    }

    // Predictive back handler
    BackHandler(enabled = activeSheet != ActiveSheet.NONE || currentScreen != ActiveScreen.HOME_DASHBOARD) {
        if (activeSheet != ActiveSheet.NONE) {
            viewModel.closeSheet()
        } else if (currentScreen != ActiveScreen.HOME_DASHBOARD) {
            viewModel.navigateTo(ActiveScreen.HOME_DASHBOARD)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        // Transisi layar: fade + sedikit zoom, halus (bukan potong mendadak)
        AnimatedContent(
            targetState = currentScreen,
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                (fadeIn(tween(600, delayMillis = 120, easing = FastOutSlowInEasing)) +
                    scaleIn(initialScale = 0.94f, animationSpec = tween(700, easing = FastOutSlowInEasing))) togetherWith
                    (fadeOut(tween(420, easing = FastOutSlowInEasing)) +
                        scaleOut(targetScale = 1.06f, animationSpec = tween(520, easing = FastOutSlowInEasing)))
            },
            label = "ScreenTransition"
        ) { screen ->
            when (screen) {
                ActiveScreen.HOME_DASHBOARD -> {
                    HomeDashboardScreen(
                        state = systemState,
                        onOpenLiveView = { viewModel.navigateTo(ActiveScreen.LIVE_VIEW_HUD) },
                        onOpenConnectionGuide = { viewModel.openSheet(ActiveSheet.CONNECTION_GUIDE) },
                        onOpenDeviceCenter = { viewModel.openSheet(ActiveSheet.DEVICE_CENTER) },
                        onShowToast = { viewModel.showToast(it) }
                    )
                }

                ActiveScreen.LIVE_VIEW_HUD -> {
                    FlightLiveViewScreen(
                        state = systemState,
                        onNavigateHome = { viewModel.navigateTo(ActiveScreen.HOME_DASHBOARD) },
                        onToggleArm = { viewModel.toggleSimulatedArm() },
                        onOpenDeviceCenter = { viewModel.openSheet(ActiveSheet.DEVICE_CENTER) },
                        onOpenRemoteCenter = { viewModel.openSheet(ActiveSheet.REMOTE_CENTER) },
                        onOpenFcCenter = { viewModel.openSheet(ActiveSheet.FC_CENTER) },
                        onOpenSensorCenter = { viewModel.openSheet(ActiveSheet.SENSOR_CENTER) },
                        onOpenPidConfig = { viewModel.openSheet(ActiveSheet.PID_CONFIG) },
                        onOpenDiagnostics = { viewModel.openSheet(ActiveSheet.DIAGNOSTICS) },
                        onOpenSettings = { viewModel.openSheet(ActiveSheet.SETTINGS) },
                        onShowToast = { viewModel.showToast(it) }
                    )
                }
            }
        }

        // Modal Sheets Overlay (muncul/hilang dengan animasi)
        AnimatedContent(
            targetState = activeSheet,
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                (fadeIn(tween(280, easing = FastOutSlowInEasing)) +
                    slideInVertically(tween(320, easing = FastOutSlowInEasing)) { it / 14 }) togetherWith
                    fadeOut(tween(200))
            },
            label = "SheetTransition"
        ) { sheet ->
        when (sheet) {
            ActiveSheet.DEVICE_CENTER -> {
                DeviceCenterSheet(
                    deviceStatus = systemState.deviceStatus,
                    onRequestPermission = { devId -> viewModel.requestUsbPermission(devId) },
                    onRefresh = { viewModel.refreshUsbDevices() },
                    onClose = { viewModel.closeSheet() }
                )
            }

            ActiveSheet.REMOTE_CENTER -> {
                RemoteCenterSheet(
                    rcTelemetry = systemState.rcTelemetry,
                    onClose = { viewModel.closeSheet() }
                )
            }

            ActiveSheet.FC_CENTER -> {
                FcCenterSheet(
                    fcStatus = systemState.fcStatus,
                    battery = systemState.battery,
                    onClose = { viewModel.closeSheet() }
                )
            }

            ActiveSheet.SENSOR_CENTER -> {
                SensorCenterSheet(
                    imu = systemState.imu,
                    baro = systemState.baro,
                    gps = systemState.gps,
                    tof = systemState.tof,
                    opticalFlow = systemState.opticalFlow,
                    sensorHealth = systemState.sensorHealth,
                    onClose = { viewModel.closeSheet() }
                )
            }

            ActiveSheet.PID_CONFIG -> {
                PidConfigSheet(
                    initialPid = systemState.pidConfig,
                    isArmed = systemState.fcStatus.armingState == com.example.model.ArmingState.ARMED,
                    onSavePid = { newPid ->
                        viewModel.applyPidParameters(newPid) { success, msg ->
                            viewModel.showToast(msg)
                            if (success) viewModel.closeSheet()
                        }
                    },
                    onClose = { viewModel.closeSheet() }
                )
            }

            ActiveSheet.DIAGNOSTICS -> {
                FlightLogsSheet(
                    logs = logs,
                    onClearLogs = { viewModel.clearLogs() },
                    onExportLogs = { viewModel.exportLogs() },
                    onClose = { viewModel.closeSheet() }
                )
            }

            ActiveSheet.SETTINGS -> {
                SettingsSheet(
                    onClose = { viewModel.closeSheet() }
                )
            }

            ActiveSheet.CONNECTION_GUIDE -> {
                ConnectionGuideDialog(
                    onOpenLiveView = {
                        viewModel.closeSheet()
                        viewModel.navigateTo(ActiveScreen.LIVE_VIEW_HUD)
                    },
                    onClose = { viewModel.closeSheet() }
                )
            }

            ActiveSheet.NONE -> Spacer(modifier = Modifier.fillMaxSize())
        }
        }
    }
}
