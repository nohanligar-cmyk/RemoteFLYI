package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cable
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AviationGreen
import com.example.ui.theme.NexendCardSurface
import com.example.ui.theme.NexendCyanPrimary

@Composable
fun ConnectionGuideDialog(
    onOpenLiveView: () -> Unit,
    onClose: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xF00F141C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Cable,
                        contentDescription = "Koneksi",
                        tint = NexendCyanPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "PANDUAN KONEKSI HARDWARE NEXEND",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Langkah menghubungkan Smartphone, USB Hub, ROTG, dan Remote RP2040",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StepCard(
                    stepNumber = "1",
                    title = "Pasang Adaptor USB-C OTG",
                    desc = "Colokkan adaptor USB-C OTG berkualitas tinggi ke port pengisian daya smartphone Android Anda. Pastikan fitur OTG aktif di pengaturan ponsel."
                )

                StepCard(
                    stepNumber = "2",
                    title = "Hubungkan USB Hub",
                    desc = "Tancapkan USB Hub ke adaptor OTG. Disarankan menggunakan USB Hub bertenaga jika smartphone tidak mencukupi daya untuk 3 perangkat sekaligus."
                )

                StepCard(
                    stepNumber = "3",
                    title = "Tancapkan Receiver ROTG FPV (Port 1)",
                    desc = "Hubungkan kabel micro-USB/USB-C dari receiver Eachine ROTG01/ROTG02 ke salah satu port USB Hub. LED receiver akan menyala merah/biru."
                )

                StepCard(
                    stepNumber = "4",
                    title = "Hubungkan Remote RP2040 (Port 2)",
                    desc = "Hubungkan remote RP2040 via kabel USB data. Begitu terhubung dan izin diberikan, aplikasi otomatis masuk ke tampilan kamera. Remote juga menjadi jalur ke drone (FC); status drone baru 'terhubung' jika telemetri FC benar-benar masuk."
                )

                StepCard(
                    stepNumber = "5",
                    title = "Berikan Izin Akses USB Host",
                    desc = "Saat dialog izin muncul di layar ponsel untuk perangkat, centang 'Selalu buka untuk perangkat ini' dan pilih 'OK'."
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = NexendCyanPrimary)
                ) {
                    Text("Tutup", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StepCard(stepNumber: String, title: String, desc: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .background(NexendCyanPrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(stepNumber, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(desc, color = Color.LightGray, fontSize = 12.sp)
            }
        }
    }
}
