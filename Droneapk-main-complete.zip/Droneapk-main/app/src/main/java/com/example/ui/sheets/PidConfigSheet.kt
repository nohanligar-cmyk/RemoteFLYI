package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ArmingState
import com.example.model.PidParameters
import com.example.ui.components.PidFlashConfirmDialog
import com.example.ui.theme.AviationRed
import com.example.ui.theme.NexendCardSurface
import com.example.ui.theme.NexendCyanPrimary

@Composable
fun PidConfigSheet(
    initialPid: PidParameters,
    isArmed: Boolean,
    onSavePid: (PidParameters) -> Unit,
    onClose: () -> Unit
) {
    var rollP by remember { mutableFloatStateOf(initialPid.rollP) }
    var rollI by remember { mutableFloatStateOf(initialPid.rollI) }
    var rollD by remember { mutableFloatStateOf(initialPid.rollD) }

    var pitchP by remember { mutableFloatStateOf(initialPid.pitchP) }
    var pitchI by remember { mutableFloatStateOf(initialPid.pitchI) }
    var pitchD by remember { mutableFloatStateOf(initialPid.pitchD) }

    var yawP by remember { mutableFloatStateOf(initialPid.yawP) }
    var yawI by remember { mutableFloatStateOf(initialPid.yawI) }
    var yawD by remember { mutableFloatStateOf(initialPid.yawD) }

    var showConfirmDialog by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xF00F141C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "PID",
                        tint = NexendCyanPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "KONFIGURASI PARAMETER PID (RP2040)",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Tuning respon dinamika penerbangan drone NEXEND",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (isArmed) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AviationRed, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "PERINGATAN: Drone sedang dalam status ARMED! Parameter PID terkunci untuk keamanan.",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                PidAxisCard("ROLL AXIS", rollP, rollI, rollD, enabled = !isArmed,
                    onPChange = { rollP = it }, onIChange = { rollI = it }, onDChange = { rollD = it })

                PidAxisCard("PITCH AXIS", pitchP, pitchI, pitchD, enabled = !isArmed,
                    onPChange = { pitchP = it }, onIChange = { pitchI = it }, onDChange = { pitchD = it })

                PidAxisCard("YAW AXIS", yawP, yawI, yawD, enabled = !isArmed,
                    onPChange = { yawP = it }, onIChange = { yawI = it }, onDChange = { yawD = it })
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedButton(
                    onClick = {
                        rollP = initialPid.rollP
                        rollI = initialPid.rollI
                        rollD = initialPid.rollD
                        pitchP = initialPid.pitchP
                        pitchI = initialPid.pitchI
                        pitchD = initialPid.pitchD
                        yawP = initialPid.yawP
                        yawI = initialPid.yawI
                        yawD = initialPid.yawD
                    },
                    enabled = !isArmed
                ) {
                    Text("Reset Nilai")
                }
                Spacer(modifier = Modifier.width(12.dp))
                Button(
                    onClick = { showConfirmDialog = true },
                    enabled = !isArmed,
                    colors = ButtonDefaults.buttonColors(containerColor = NexendCyanPrimary)
                ) {
                    Icon(Icons.Default.Save, contentDescription = "Simpan", tint = Color.Black, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Terapkan ke RP2040", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showConfirmDialog) {
        PidFlashConfirmDialog(
            onConfirm = {
                showConfirmDialog = false
                val newPid = initialPid.copy(
                    rollP = rollP, rollI = rollI, rollD = rollD,
                    pitchP = pitchP, pitchI = pitchI, pitchD = pitchD,
                    yawP = yawP, yawI = yawI, yawD = yawD
                )
                onSavePid(newPid)
            },
            onDismiss = { showConfirmDialog = false }
        )
    }
}

@Composable
private fun PidAxisCard(
    axisName: String,
    p: Float,
    i: Float,
    d: Float,
    enabled: Boolean,
    onPChange: (Float) -> Unit,
    onIChange: (Float) -> Unit,
    onDChange: (Float) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(axisName, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Proportional (P): ${p.toInt()}", color = NexendCyanPrimary, fontSize = 12.sp)
                    Slider(value = p, onValueChange = onPChange, valueRange = 10f..150f, enabled = enabled)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Integral (I): ${i.toInt()}", color = NexendCyanPrimary, fontSize = 12.sp)
                    Slider(value = i, onValueChange = onIChange, valueRange = 10f..150f, enabled = enabled)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("Derivative (D): ${d.toInt()}", color = NexendCyanPrimary, fontSize = 12.sp)
                    Slider(value = d, onValueChange = onDChange, valueRange = 0f..80f, enabled = enabled)
                }
            }
        }
    }
}
