package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.FlightLogEntry
import com.example.model.PidParameters
import com.example.repository.DroneRepository
import com.example.repository.DroneSystemState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

enum class ActiveSheet {
    NONE,
    DEVICE_CENTER,
    REMOTE_CENTER,
    FC_CENTER,
    SENSOR_CENTER,
    PID_CONFIG,
    DIAGNOSTICS,
    SETTINGS,
    CONNECTION_GUIDE
}

enum class ActiveScreen {
    HOME_DASHBOARD,
    LIVE_VIEW_HUD
}

class DroneViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = DroneRepository(application.applicationContext)

    val systemState: StateFlow<DroneSystemState> = repository.systemState
    val logs: StateFlow<List<FlightLogEntry>> = repository.diagnosticsLogger.logsFlow

    private val _currentScreen = MutableStateFlow(ActiveScreen.HOME_DASHBOARD)
    val currentScreen: StateFlow<ActiveScreen> = _currentScreen.asStateFlow()

    private val _activeSheet = MutableStateFlow(ActiveSheet.NONE)
    val activeSheet: StateFlow<ActiveSheet> = _activeSheet.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    init {
        // Remote baru tersambung (false -> true) saat di Home => otomatis masuk tampilan kamera.
        // Hanya pada "tepi" perubahan, jadi kalau pengguna sengaja kembali ke Home dengan
        // remote masih terpasang, aplikasi tidak memaksa masuk lagi.
        viewModelScope.launch {
            repository.systemState
                .map { it.canOpenCameraView }
                .distinctUntilChanged()
                .collect { canOpen ->
                    if (canOpen && _currentScreen.value == ActiveScreen.HOME_DASHBOARD) {
                        _activeSheet.value = ActiveSheet.NONE
                        _currentScreen.value = ActiveScreen.LIVE_VIEW_HUD
                    }
                }
        }
    }

    fun navigateTo(screen: ActiveScreen) {
        // Tampilan kamera hanya bisa dibuka bila remote terhubung (atau mode simulasi)
        if (screen == ActiveScreen.LIVE_VIEW_HUD && !repository.systemState.value.canOpenCameraView) {
            showToast("Hubungkan remote (RP2040) lewat OTG terlebih dahulu")
            return
        }
        _currentScreen.value = screen
    }

    fun openSheet(sheet: ActiveSheet) {
        _activeSheet.value = sheet
    }

    fun closeSheet() {
        _activeSheet.value = ActiveSheet.NONE
    }

    fun toggleSimulationMode(enabled: Boolean) {
        repository.setSimulationMode(enabled)
    }

    fun toggleSimulatedArm() {
        repository.toggleSimulatedArm()
    }

    fun onUsbIntent() {
        repository.refreshUsbDevices()
    }

    fun refreshUsbDevices() {
        repository.refreshUsbDevices()
    }

    fun requestUsbPermission(deviceId: Int) {
        repository.requestUsbPermission(deviceId)
    }

    fun applyPidParameters(newPid: PidParameters, onResult: (Boolean, String) -> Unit) {
        repository.applyPidParameters(newPid, onResult)
    }

    fun clearLogs() {
        repository.diagnosticsLogger.clear()
    }

    fun exportLogs(): String {
        return repository.diagnosticsLogger.exportFormattedString()
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        repository.cleanup()
    }
}
