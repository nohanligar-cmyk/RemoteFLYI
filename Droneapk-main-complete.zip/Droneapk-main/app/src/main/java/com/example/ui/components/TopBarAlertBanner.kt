package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AviationAmberBg
import com.example.ui.theme.AviationGreenBg
import com.example.ui.theme.AviationRedBg

enum class BannerType {
    ERROR,
    WARNING,
    SUCCESS,
    INFO
}

@Composable
fun TopBarAlertBanner(
    text: String,
    type: BannerType = BannerType.ERROR,
    onClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val bgColor = when (type) {
        BannerType.ERROR -> Color(0xE6E53935)
        BannerType.WARNING -> Color(0xE6FB8C00)
        BannerType.SUCCESS -> Color(0xE643A047)
        BannerType.INFO -> Color(0xE60288D1)
    }

    Box(
        modifier = modifier
            .background(bgColor, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}
