package com.example.model

enum class NexendDeviceType {
    ROTG_VIDEO_RECEIVER,
    ESP32_C3_RC,
    RP2040_FC,
    GENERIC_USB_DEVICE,
    UNKNOWN
}

enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    STALE,
    ERROR,
    UNSUPPORTED
}

data class UsbDeviceItem(
    val deviceId: Int,
    val deviceName: String,
    val vendorId: Int,
    val productId: Int,
    val manufacturerName: String?,
    val productName: String?,
    val detectedType: NexendDeviceType,
    val interfaceCount: Int,
    val interfacesDescription: String,
    val hasPermission: Boolean,
    val isConnected: Boolean,
    /** true bila port data sudah dibuka & sedang dibaca aplikasi */
    val isOpen: Boolean = false,
    val lastError: String? = null
) {
    /** RP2040 (utama) atau adaptor serial lama dianggap sebagai REMOTE. */
    val isRemote: Boolean
        get() = detectedType == NexendDeviceType.RP2040_FC || detectedType == NexendDeviceType.ESP32_C3_RC

    val vidPidFormatted: String
        get() = String.format("VID: 0x%04X | PID: 0x%04X", vendorId, productId)
}

data class DeviceCenterStatus(
    val connectedDevices: List<UsbDeviceItem> = emptyList(),
    val rotgReceiver: UsbDeviceItem? = null,
    val remoteController: UsbDeviceItem? = null,
    val flightController: UsbDeviceItem? = null,
    /** Remote (RP2040) terdeteksi + izin diberikan + port data terbuka. */
    val remoteReady: Boolean = false,
    val isUsbHubDetected: Boolean = false,
    val totalDevicesAttached: Int = 0
)
