package com.example.video

import com.example.model.VideoFeedStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class VideoReceiverManager(
    private val scope: CoroutineScope,
    private val onLog: (severity: String, message: String) -> Unit
) {
    private val _videoStats = MutableStateFlow(
        VideoFeedStats(
            isReceiving = false,
            format = "N/A",
            resolutionWidth = 0,
            resolutionHeight = 0,
            fps = 0,
            bitrateKbps = 0,
            droppedFrames = 0,
            decoderLatencyMs = 0
        )
    )
    val videoStats: StateFlow<VideoFeedStats> = _videoStats.asStateFlow()

    private var monitorJob: Job? = null
    private var isSimulatingVideo = false

    fun startStreamMonitoring(isSimulation: Boolean) {
        isSimulatingVideo = isSimulation
        monitorJob?.cancel()

        monitorJob = scope.launch(Dispatchers.Default) {
            var frameCount = 0
            while (isActive) {
                delay(1000)
                if (isSimulatingVideo) {
                    frameCount += 60
                    _videoStats.value = VideoFeedStats(
                        isReceiving = true,
                        format = "UVC MJPEG (Simulated)",
                        resolutionWidth = 720,
                        resolutionHeight = 576, // Standard PAL FPV 720x576 60fps
                        fps = 60,
                        bitrateKbps = 4800,
                        droppedFrames = 0,
                        decoderLatencyMs = 28,
                        receiverModel = "ROTG02 Dual Antenna FPV",
                        lastFrameTimestampMs = System.currentTimeMillis()
                    )
                } else {
                    // When in hardware mode with no hardware UVC device attached
                    _videoStats.value = _videoStats.value.copy(
                        isReceiving = false,
                        fps = 0,
                        format = "NO SIGNAL / DISCONNECTED"
                    )
                }
            }
        }
    }

    fun onHardwareFrameReceived(width: Int, height: Int, format: String) {
        _videoStats.value = VideoFeedStats(
            isReceiving = true,
            format = format,
            resolutionWidth = width,
            resolutionHeight = height,
            fps = 60,
            bitrateKbps = 5200,
            droppedFrames = 0,
            decoderLatencyMs = 32,
            receiverModel = "ROTG02 USB FPV",
            lastFrameTimestampMs = System.currentTimeMillis()
        )
    }

    fun stopStream() {
        monitorJob?.cancel()
        _videoStats.value = _videoStats.value.copy(
            isReceiving = false,
            fps = 0
        )
    }
}
