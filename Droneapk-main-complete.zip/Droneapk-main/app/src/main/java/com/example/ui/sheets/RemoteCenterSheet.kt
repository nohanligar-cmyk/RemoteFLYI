package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.RcTelemetry
import com.example.ui.theme.AviationGreen
import com.example.ui.theme.AviationRed
import com.example.ui.theme.NexendCardSurface
import com.example.ui.theme.NexendCyanPrimary

@Composable
fun RemoteCenterSheet(
    rcTelemetry: RcTelemetry,
    onClose: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xF00F141C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Gamepad,
                        contentDescription = "Remote",
                        tint = NexendCyanPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "PUSAT PENGENDALI JARAK JAUH (REMOTE CENTER)",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "RP2040 Remote • USB OTG • Link ke Drone via FC",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Link Health Summary
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF161F2A), RoundedCornerShape(8.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                MetricItem(
                    label = "Status Sambungan",
                    value = if (rcTelemetry.isConnected) "TERHUBUNG" else "TERPUTUS",
                    color = if (rcTelemetry.isConnected) AviationGreen else AviationRed
                )
                MetricItem(
                    label = "Sinyal (RSSI)",
                    value = "${rcTelemetry.rssiDbm} dBm",
                    color = if (rcTelemetry.rssiDbm > -80) AviationGreen else AviationRed
                )
                MetricItem(
                    label = "Packet Loss",
                    value = String.format("%.1f %%", rcTelemetry.packetLossPercent),
                    color = if (rcTelemetry.packetLossPercent < 2f) AviationGreen else Color(0xFFFFB300)
                )
                MetricItem(
                    label = "Latency",
                    value = "${rcTelemetry.latencyMs} ms",
                    color = NexendCyanPrimary
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sticks & Switches
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                // Sticks
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "POSISI TONGKAT KENDALI (STICKS)",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        StickBar(name = "Throttle (CH1)", value = rcTelemetry.throttlePercent, min = 0, max = 100)
                        StickBar(name = "Yaw / Rudder (CH2)", value = rcTelemetry.yawStickPercent, min = -100, max = 100)
                        StickBar(name = "Pitch / Elevator (CH3)", value = rcTelemetry.pitchStickPercent, min = -100, max = 100)
                        StickBar(name = "Roll / Aileron (CH4)", value = rcTelemetry.rollStickPercent, min = -100, max = 100)
                    }
                }

                // Switches & Firmware
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "SAKLAR AUXILIARY (SWITCHES)",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        SwitchItem(name = "SA (Arm Switch)", position = if (rcTelemetry.switchA > 50) "ARMED" else "DISARM")
                        SwitchItem(name = "SB (Flight Mode)", position = "POS-HOLD (MID)")
                        SwitchItem(name = "SC (RTH / Failsafe)", position = "OFF")
                        SwitchItem(name = "SD (Beeper / Aux)", position = "OFF")

                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Firmware Remote: ${rcTelemetry.firmwareVersion}",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = Color.Gray, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StickBar(name: String, value: Int, min: Int, max: Int) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(name, color = Color.LightGray, fontSize = 12.sp)
            Text("$value %", color = NexendCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        val normalized = ((value - min).toFloat() / (max - min)).coerceIn(0f, 1f)
        LinearProgressIndicator(
            progress = { normalized },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp),
            color = NexendCyanPrimary,
            trackColor = Color(0xFF233040)
        )
    }
}

@Composable
private fun SwitchItem(name: String, position: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(name, color = Color.LightGray, fontSize = 12.sp)
        Text(position, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
