package com.example.diagnostics

import com.example.model.FlightLogEntry
import com.example.model.LogSeverity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DiagnosticsLogger {
    companion object {
        private const val MAX_LOGS = 500
    }

    private val logList = mutableListOf<FlightLogEntry>()
    private val _logsFlow = MutableStateFlow<List<FlightLogEntry>>(emptyList())
    val logsFlow: StateFlow<List<FlightLogEntry>> = _logsFlow.asStateFlow()

    private val dateFormat = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())

    fun log(severity: LogSeverity, category: String, message: String, details: String? = null) {
        synchronized(logList) {
            val entry = FlightLogEntry(
                id = System.nanoTime(),
                timestampMs = System.currentTimeMillis(),
                severity = severity,
                category = category,
                message = message,
                details = details
            )
            logList.add(0, entry)
            if (logList.size > MAX_LOGS) {
                logList.removeAt(logList.size - 1)
            }
            _logsFlow.value = logList.toList()
        }
    }

    fun clear() {
        synchronized(logList) {
            logList.clear()
            _logsFlow.value = emptyList()
        }
    }

    fun exportFormattedString(): String {
        synchronized(logList) {
            return buildString {
                appendLine("=== NEXEND FLY DIAGNOSTIC LOG EXPORT ===")
                appendLine("Generated: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}")
                appendLine("Total Entries: ${logList.size}")
                appendLine("=========================================")
                for (entry in logList.reversed()) {
                    val time = dateFormat.format(Date(entry.timestampMs))
                    appendLine("[$time] [${entry.severity}] [${entry.category}] ${entry.message}")
                    if (!entry.details.isNullOrBlank()) {
                        appendLine("    Details: ${entry.details}")
                    }
                }
            }
        }
    }
}
