package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ArmingState
import com.example.model.BatteryTelemetry
import com.example.model.FcStatus
import com.example.ui.theme.AviationGreen
import com.example.ui.theme.AviationRed
import com.example.ui.theme.NexendCardSurface
import com.example.ui.theme.NexendCyanPrimary

@Composable
fun FcCenterSheet(
    fcStatus: FcStatus,
    battery: BatteryTelemetry,
    onClose: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xF00F141C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = "FC",
                        tint = NexendCyanPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "PUSAT FLIGHT CONTROLLER (RP2040)",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Dual-Core ARM Cortex-M0+ @ 133MHz • NX-PROTO 1.4",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Summary metrics
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF161F2A), RoundedCornerShape(8.dp))
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                StatusItem("Koneksi FC", if (fcStatus.isConnected) "ONLINE" else "OFFLINE", if (fcStatus.isConnected) AviationGreen else AviationRed)
                StatusItem("Status Arm", fcStatus.armingState.label, if (fcStatus.armingState == ArmingState.ARMED) AviationRed else AviationGreen)
                StatusItem("Mode Terbang", fcStatus.flightMode.displayName, NexendCyanPrimary)
                StatusItem("Tegangan Baterai", String.format("%.2f V", battery.voltage), if (battery.voltage > 14.8f) AviationGreen else Color(0xFFFFB300))
                StatusItem("CPU Load", "${fcStatus.cpuLoadPercent} %", Color.White)
                StatusItem("PID Loop Time", "${fcStatus.loopTimeUs} µs (4kHz)", NexendCyanPrimary)
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("INFORMASI SISTEM FC", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        RowText("Firmware", fcStatus.firmwareVersion)
                        RowText("Protokol", fcStatus.protocolVersion)
                        RowText("Waktu Penerbangan", "${fcStatus.flightTimeSeconds} detik")
                        RowText("Failsafe State", if (fcStatus.failsafeTriggered) "AKTIF (DARURAT)" else "NORMAL")
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("TELEMETRI DAYA & BATERAI (4S LiPo)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        RowText("Arus Saat Ini", String.format("%.1f A", battery.currentAmps))
                        RowText("Daya Terpakai", "${battery.consumedMah} mAh")
                        RowText("Kapasitas Sisa", "${battery.remainingPercent} %")
                        RowText("Tegangan Rata Sel", String.format("%.2f V/cell", if (battery.voltage > 0) battery.voltage / 4f else 0f))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, color = Color.Gray, fontSize = 11.sp)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = value, color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun RowText(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color.LightGray, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}
