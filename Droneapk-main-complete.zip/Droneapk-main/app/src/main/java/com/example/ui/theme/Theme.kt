package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NexendDarkColorScheme = darkColorScheme(
    primary = NexendCyanPrimary,
    onPrimary = Color(0xFF00363D),
    primaryContainer = Color(0xFF004F58),
    onPrimaryContainer = Color(0xFF8DF2FF),
    secondary = NexendCyanSecondary,
    onSecondary = Color(0xFF00344F),
    secondaryContainer = Color(0xFF004C70),
    onSecondaryContainer = Color(0xFFCBE6FF),
    tertiary = NexendAccentGold,
    onTertiary = Color(0xFF432C00),
    background = NexendDarkBackground,
    onBackground = NexendTextPrimary,
    surface = NexendDarkSurface,
    onSurface = NexendTextPrimary,
    surfaceVariant = Color(0xFF1B232E),
    onSurfaceVariant = NexendTextSecondary,
    error = AviationRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NexendDarkColorScheme,
        typography = Typography,
        content = content
    )
}
