package com.example.usb

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.model.DeviceCenterStatus
import com.example.model.NexendDeviceType
import com.example.model.UsbDeviceItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Mengelola semua perangkat USB (OTG).
 *
 * RP2040 berfungsi sebagai REMOTE sekaligus jembatan ke FC. Jadi:
 *  - "remote terhubung"  = RP2040 terdeteksi + izin USB diberikan + port data berhasil dibuka
 *  - "drone/FC terhubung" = ditentukan di DroneRepository dari paket telemetri yang benar-benar masuk
 */
class NexendUsbManager(
    context: Context,
    private val scope: CoroutineScope,
    private val onDataReceived: (deviceType: NexendDeviceType, data: ByteArray) -> Unit,
    private val onLog: (severity: String, message: String) -> Unit
) {
    companion object {
        private const val TAG = "NexendUsbManager"
        const val ACTION_USB_PERMISSION = "com.example.nexendfly.USB_PERMISSION"

        // CDC-ACM class requests
        private const val CDC_REQTYPE_OUT = 0x21
        private const val CDC_SET_LINE_CODING = 0x20
        private const val CDC_SET_CONTROL_LINE_STATE = 0x22
    }

    private val context: Context = context.applicationContext

    private val usbManager: UsbManager? =
        this.context.getSystemService(Context.USB_SERVICE) as? UsbManager

    private val _deviceStatus = MutableStateFlow(DeviceCenterStatus())
    val deviceStatus: StateFlow<DeviceCenterStatus> = _deviceStatus.asStateFlow()

    private val lock = Any()
    private val activeConnections = mutableMapOf<Int, UsbDeviceConnection>()
    private val claimedInterfaces = mutableMapOf<Int, List<UsbInterface>>()
    private val ioJobs = mutableMapOf<Int, Job>()

    /** deviceId yang sudah pernah diminta izinnya otomatis (agar dialog tidak muncul berulang). */
    private val autoRequested = mutableSetOf<Int>()

    private fun usbDeviceFrom(intent: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(pContext: Context?, intent: Intent?) {
            // Exception apa pun di sini sebelumnya bisa menjatuhkan seluruh aplikasi (force close).
            try {
                when (intent?.action) {
                    ACTION_USB_PERMISSION -> {
                        val device = usbDeviceFrom(intent)
                        val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                        if (device != null) {
                            if (granted) {
                                onLog("INFO", "Izin USB diberikan: ${device.deviceName}")
                                openDevice(device)
                            } else {
                                onLog("WARN", "Izin USB DITOLAK: ${device.deviceName}")
                            }
                        }
                        refreshDevices(autoRequest = false)
                    }
                    UsbManager.ACTION_USB_DEVICE_ATTACHED -> {
                        onLog("INFO", "Perangkat USB tersambung ke port OTG")
                        refreshDevices(autoRequest = true)
                    }
                    UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                        val device = usbDeviceFrom(intent)
                        if (device != null) {
                            onLog("WARN", "Perangkat USB dicabut: ${device.deviceName}")
                            synchronized(lock) {
                                closeDevice(device.deviceId)
                                autoRequested.remove(device.deviceId)
                            }
                        }
                        refreshDevices(autoRequest = false)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "USB receiver error", e)
                onLog("ERROR", "Kesalahan USB: ${e.message}")
            }
        }
    }

    init {
        val filter = IntentFilter().apply {
            addAction(ACTION_USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        ContextCompat.registerReceiver(this.context, usbReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        refreshDevices(autoRequest = true)
    }

    /**
     * Pindai ulang perangkat. Perangkat remote (RP2040) yang sudah punya izin dibuka otomatis;
     * yang belum punya izin diminta izinnya sekali (jika [autoRequest]).
     */
    fun refreshDevices(autoRequest: Boolean = false) {
        val um = usbManager
        if (um == null) {
            onLog("WARN", "USB Host tidak tersedia di perangkat ini")
            return
        }

        try {
            val itemList = mutableListOf<UsbDeviceItem>()
            var rotgItem: UsbDeviceItem? = null
            var remoteItem: UsbDeviceItem? = null
            var remoteReady = false

            synchronized(lock) {
                val devices = um.deviceList.values.toList()

                // Bersihkan koneksi milik perangkat yang sudah tidak ada
                val presentIds = devices.map { it.deviceId }.toSet()
                (activeConnections.keys - presentIds).forEach { closeDevice(it) }
                autoRequested.retainAll(presentIds)

                for (device in devices) {
                    val hasPermission = um.hasPermission(device)
                    var item = UsbDeviceDetector.identifyDevice(device, hasPermission)

                    if (item.isRemote) {
                        if (hasPermission && !activeConnections.containsKey(device.deviceId)) {
                            openDevice(device)
                        } else if (!hasPermission && autoRequest && autoRequested.add(device.deviceId)) {
                            requestPermissionInternal(um, device)
                        }
                    }

                    val isOpen = activeConnections.containsKey(device.deviceId)
                    item = item.copy(isOpen = isOpen)
                    itemList.add(item)

                    when {
                        item.detectedType == NexendDeviceType.ROTG_VIDEO_RECEIVER -> rotgItem = item
                        item.isRemote -> {
                            // Jika ada beberapa kandidat, pilih yang sudah terbuka
                            if (remoteItem == null || (isOpen && remoteItem?.isOpen != true)) {
                                remoteItem = item
                            }
                        }
                    }
                }
                remoteReady = remoteItem?.isOpen == true
            }

            _deviceStatus.value = DeviceCenterStatus(
                connectedDevices = itemList,
                rotgReceiver = rotgItem,
                // RP2040 = remote sekaligus jalur ke FC, jadi menunjuk perangkat yang sama
                remoteController = remoteItem,
                flightController = remoteItem,
                remoteReady = remoteReady,
                isUsbHubDetected = itemList.size > 1,
                totalDevicesAttached = itemList.size
            )
        } catch (e: Exception) {
            Log.e(TAG, "refreshDevices failed", e)
            onLog("ERROR", "Gagal memindai USB: ${e.message}")
        }
    }

    /** Dipanggil dari tombol "Minta Izin USB". */
    fun requestPermissionForDevice(deviceId: Int) {
        val um = usbManager ?: return
        try {
            val device = um.deviceList.values.find { it.deviceId == deviceId } ?: return
            if (um.hasPermission(device)) {
                synchronized(lock) { openDevice(device) }
                refreshDevices(autoRequest = false)
                return
            }
            requestPermissionInternal(um, device)
        } catch (e: Exception) {
            Log.e(TAG, "requestPermission failed", e)
            onLog("ERROR", "Gagal meminta izin USB: ${e.message}")
        }
    }

    private fun requestPermissionInternal(um: UsbManager, device: UsbDevice) {
        // Android 12+ mewajibkan flag mutable/immutable. Izin USB HARUS mutable (sistem mengisi
        // EXTRA_DEVICE & EXTRA_PERMISSION_GRANTED). Android 14+ melempar SecurityException
        // (force close) bila PendingIntent mutable dibuat dengan Intent implisit, jadi paket
        // aplikasi wajib di-set agar intent-nya eksplisit.
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val intent = Intent(ACTION_USB_PERMISSION).setPackage(context.packageName)
        val permissionIntent = PendingIntent.getBroadcast(context, device.deviceId, intent, flags)
        onLog("INFO", "Meminta izin USB: ${device.deviceName}")
        um.requestPermission(device, permissionIntent)
    }

    /** Harus dipanggil di dalam synchronized(lock). */
    private fun openDevice(device: UsbDevice) {
        val um = usbManager ?: return
        try {
            if (!um.hasPermission(device)) return
            if (activeConnections.containsKey(device.deviceId)) return

            val item = UsbDeviceDetector.identifyDevice(device, true)
            // Receiver video (UVC) tidak dibaca lewat jalur serial ini
            if (item.detectedType == NexendDeviceType.ROTG_VIDEO_RECEIVER || !item.isRemote) return

            // Cari interface data (CDC-Data lebih diutamakan) beserta endpoint bulk IN/OUT
            var ctrlIface: UsbInterface? = null
            var dataIface: UsbInterface? = null
            var inEp: UsbEndpoint? = null
            var outEp: UsbEndpoint? = null

            for (i in 0 until device.interfaceCount) {
                val iface = device.getInterface(i)
                if (iface.interfaceClass == UsbConstants.USB_CLASS_COMM) ctrlIface = iface
            }
            val ordered = (0 until device.interfaceCount).map { device.getInterface(it) }
                .sortedBy { if (it.interfaceClass == UsbConstants.USB_CLASS_CDC_DATA) 0 else 1 }
            for (iface in ordered) {
                if (iface.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE ||
                    iface.interfaceClass == UsbConstants.USB_CLASS_VIDEO
                ) continue
                var foundIn: UsbEndpoint? = null
                var foundOut: UsbEndpoint? = null
                for (e in 0 until iface.endpointCount) {
                    val ep = iface.getEndpoint(e)
                    if (ep.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
                    if (ep.direction == UsbConstants.USB_DIR_IN) foundIn = foundIn ?: ep
                    else foundOut = foundOut ?: ep
                }
                if (foundIn != null) {
                    dataIface = iface
                    inEp = foundIn
                    outEp = foundOut
                    break
                }
            }

            if (dataIface == null || inEp == null) {
                onLog("ERROR", "Port data bulk tidak ditemukan pada ${device.deviceName}")
                return
            }

            val connection = um.openDevice(device)
            if (connection == null) {
                onLog("ERROR", "Gagal membuka perangkat USB: ${device.deviceName}")
                return
            }

            val claimed = mutableListOf<UsbInterface>()
            if (ctrlIface != null && ctrlIface.id != dataIface.id && connection.claimInterface(ctrlIface, true)) {
                claimed.add(ctrlIface)
            }
            if (!connection.claimInterface(dataIface, true)) {
                onLog("ERROR", "Gagal claim interface data ${device.deviceName}")
                connection.close()
                return
            }
            claimed.add(dataIface)

            // CDC-ACM: aktifkan DTR/RTS & set 115200 8N1 (firmware Pico/TinyUSB menunggu DTR)
            if (ctrlIface != null) {
                try {
                    val lineCoding = byteArrayOf(
                        0x00, 0xC2.toByte(), 0x01, 0x00, // 115200
                        0x00, 0x00, 0x08                 // 1 stop, no parity, 8 data
                    )
                    connection.controlTransfer(CDC_REQTYPE_OUT, CDC_SET_LINE_CODING, 0, ctrlIface.id, lineCoding, lineCoding.size, 200)
                    connection.controlTransfer(CDC_REQTYPE_OUT, CDC_SET_CONTROL_LINE_STATE, 0x03, ctrlIface.id, null, 0, 200)
                } catch (e: Exception) {
                    Log.w(TAG, "CDC init failed (diabaikan)", e)
                }
            }

            activeConnections[device.deviceId] = connection
            claimedInterfaces[device.deviceId] = claimed

            val readEp: UsbEndpoint = inEp
            val deviceId = device.deviceId
            val type = item.detectedType
            ioJobs[deviceId] = scope.launch(Dispatchers.IO) {
                val buffer = ByteArray(1024)
                try {
                    while (isActive) {
                        val n = connection.bulkTransfer(readEp, buffer, buffer.size, 100)
                        if (n > 0) {
                            onDataReceived(type, buffer.copyOf(n))
                        } else if (n < 0) {
                            // -1 = timeout (normal) ATAU koneksi sudah ditutup
                            val stillOpen = synchronized(lock) { activeConnections[deviceId] === connection }
                            if (!stillOpen) break
                            delay(5)
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "USB read loop error", e)
                    onLog("ERROR", "Pembacaan USB berhenti: ${e.message}")
                }
            }
            onLog("INFO", "Remote RP2040 terbuka & siap (${item.vidPidFormatted})")
        } catch (e: SecurityException) {
            onLog("ERROR", "Izin USB hilang untuk ${device.deviceName}")
        } catch (e: Exception) {
            Log.e(TAG, "openDevice failed", e)
            onLog("ERROR", "Gagal membuka USB: ${e.message}")
        }
    }

    /** Harus dipanggil di dalam synchronized(lock). */
    private fun closeDevice(deviceId: Int) {
        ioJobs.remove(deviceId)?.cancel()
        val conn = activeConnections.remove(deviceId)
        val ifaces = claimedInterfaces.remove(deviceId)
        try {
            ifaces?.forEach { conn?.releaseInterface(it) }
        } catch (_: Exception) {
        }
        try {
            conn?.close()
        } catch (_: Exception) {
        }
    }

    fun cleanup() {
        try {
            context.unregisterReceiver(usbReceiver)
        } catch (e: Exception) {
            Log.e(TAG, "Error unregistering receiver", e)
        }
        synchronized(lock) {
            activeConnections.keys.toList().forEach { closeDevice(it) }
        }
    }
}
