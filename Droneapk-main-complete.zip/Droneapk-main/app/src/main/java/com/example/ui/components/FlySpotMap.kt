package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.model.LatLng

/** Posisi awal bila lokasi pengguna belum diketahui (Jakarta). */
private val DEFAULT_CENTER = LatLng(-6.2088, 106.8456)

/**
 * Lokasi pengguna lewat LocationManager bawaan Android (tanpa dependensi tambahan).
 * Mengembalikan null sampai lokasi pertama didapat.
 */
@SuppressLint("MissingPermission")
@Composable
fun rememberUserLocation(permissionGranted: Boolean): State<LatLng?> {
    val context = LocalContext.current
    val state = remember { mutableStateOf<LatLng?>(null) }

    LaunchedEffect(permissionGranted) {
        if (!permissionGranted) return@LaunchedEffect
        try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
                ?: return@LaunchedEffect
            val providers = lm.getProviders(true)

            // 1) Lokasi terakhir yang diketahui (instan)
            providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
                .maxByOrNull { it.time }
                ?.let { state.value = LatLng(it.latitude, it.longitude) }

            // 2) Lokasi segar
            val provider = when {
                LocationManager.GPS_PROVIDER in providers -> LocationManager.GPS_PROVIDER
                LocationManager.NETWORK_PROVIDER in providers -> LocationManager.NETWORK_PROVIDER
                else -> null
            }
            if (provider != null) {
                // Satu kali update saja lewat LocationListener (tanpa overload yang ambigu)
                val listener = object : LocationListener {
                    override fun onLocationChanged(loc: Location) {
                        state.value = LatLng(loc.latitude, loc.longitude)
                        try {
                            lm.removeUpdates(this)
                        } catch (_: Exception) {
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                    override fun onProviderEnabled(provider: String) {}
                    override fun onProviderDisabled(provider: String) {}
                }
                lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
            }
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }
    return state
}

/**
 * Google Maps asli (Maps SDK for Android) untuk kartu "Sebelum Terbang".
 * Titik biru = posisi pengguna; kamera otomatis memusatkan ke posisi tersebut.
 */
@SuppressLint("MissingPermission")
@Composable
fun FlySpotMap(
    locationPermissionGranted: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val userLocation by rememberUserLocation(locationPermissionGranted)
    val mapRef = remember { mutableStateOf<GoogleMap?>(null) }
    val mapView = remember { MapView(context) }
    val currentLocation = rememberUpdatedState(userLocation)
    var centered by remember { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner, mapView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_CREATE -> mapView.onCreate(Bundle())
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        mapView.getMapAsync { map ->
            map.mapType = GoogleMap.MAP_TYPE_NORMAL
            map.uiSettings.isZoomControlsEnabled = false
            map.uiSettings.isMyLocationButtonEnabled = false
            map.uiSettings.isMapToolbarEnabled = false
            map.uiSettings.isCompassEnabled = false
            map.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLocation.value ?: DEFAULT_CENTER, if (currentLocation.value != null) 15f else 10f))
            mapRef.value = map
        }
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            // Composable keluar dari layar (mis. pindah ke tampilan kamera) sementara Activity masih hidup
            val cur = lifecycleOwner.lifecycle.currentState
            if (cur.isAtLeast(Lifecycle.State.RESUMED)) mapView.onPause()
            if (cur.isAtLeast(Lifecycle.State.STARTED)) mapView.onStop()
            if (cur != Lifecycle.State.DESTROYED) mapView.onDestroy()
        }
    }

    // Aktifkan titik biru lokasi saat izin ada
    LaunchedEffect(mapRef.value, locationPermissionGranted) {
        val map = mapRef.value ?: return@LaunchedEffect
        try {
            map.isMyLocationEnabled = locationPermissionGranted
        } catch (_: SecurityException) {
        }
    }

    // Animasikan kamera ke posisi pengguna ketika lokasi pertama didapat
    LaunchedEffect(mapRef.value, userLocation) {
        val map = mapRef.value ?: return@LaunchedEffect
        val loc = userLocation ?: return@LaunchedEffect
        if (!centered) {
            centered = true
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(loc, 15f))
        }
    }

    AndroidView(factory = { mapView }, modifier = modifier)
}
