package com.example.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AviationRed

@Composable
fun SafetyArmingDialog(
    isArmed: Boolean,
    isSimulation: Boolean,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isArmed) "KONFIRMASI DISARM" else "PERINGATAN KESELAMATAN: ARM DRONE",
                color = if (isArmed) Color.White else AviationRed,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column {
                if (isArmed) {
                    Text(
                        "Apakah Anda yakin ingin mematikan motor (DISARM)? Jika pesawat sedang berada di udara, motor akan langsung berhenti berputar.",
                        color = Color.LightGray
                    )
                } else {
                    Text(
                        if (isSimulation)
                            "Mode Simulasi: Motor virtual akan diaktifkan untuk simulasi penerbangan."
                        else
                            "PERHATIAN! Mempersenjatai (ARM) drone akan segera memutar baling-baling. Pastikan area sekitar aman, tidak ada orang atau halangan dalam radius 5 meter, dan baterai terpasang kokoh.",
                        color = Color.LightGray
                    )
                }
                if (!isSimulation) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "Flight Controller RP2040 akan memverifikasi sensor pre-arm sebelum aktivasi motor.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isArmed) MaterialTheme.colorScheme.primary else AviationRed
                )
            ) {
                Text(if (isArmed) "Lanjutkan Disarm" else "Saya Mengerti & ARM")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}

@Composable
fun PidFlashConfirmDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Tulis Parameter PID ke FC?",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Text(
                "Nilai PID baru akan dikirim melalui USB serial ke Raspberry Pi Pico RP2040 dan disimpan ke flash. Drone harus dalam kondisi DISARM.",
                color = Color.LightGray
            )
        },
        confirmButton = {
            Button(onClick = onConfirm) {
                Text("Terapkan ke FC")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Batal")
            }
        }
    )
}
