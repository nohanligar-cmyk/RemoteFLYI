package com.example.ui.sheets

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BaroTelemetry
import com.example.model.GpsTelemetry
import com.example.model.ImuTelemetry
import com.example.model.OpticalFlowTelemetry
import com.example.model.SensorHealth
import com.example.model.ToFTelemetry
import com.example.ui.theme.AviationGreen
import com.example.ui.theme.AviationRed
import com.example.ui.theme.NexendCardSurface
import com.example.ui.theme.NexendCyanPrimary

@Composable
fun SensorCenterSheet(
    imu: ImuTelemetry,
    baro: BaroTelemetry,
    gps: GpsTelemetry,
    tof: ToFTelemetry,
    opticalFlow: OpticalFlowTelemetry,
    sensorHealth: SensorHealth,
    onClose: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xF00F141C)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Sensors,
                        contentDescription = "Sensors",
                        tint = NexendCyanPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "PUSAT SENSOR & DIAGNOSTIK (SENSOR CENTER)",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Status kalibrasi, validitas sinyal, dan pembacaan waktu nyata",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // IMU Card
                item {
                    SensorCard(
                        title = "IMU (ICM-42688P / MPU6000 6-Axis)",
                        isHealthy = sensorHealth.imuHealthy,
                        isDetected = sensorHealth.imuDetected
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Sikap (Roll/Pitch/Yaw): ${String.format("%.1f° / %.1f° / %.1f°", imu.rollDeg, imu.pitchDeg, imu.yawDeg)}", color = Color.White, fontSize = 12.sp)
                            Text("Gyro X/Y/Z: ${String.format("%.1f / %.1f / %.1f °/s", imu.gyroXDegPerSec, imu.gyroYDegPerSec, imu.gyroZDegPerSec)}", color = Color.LightGray, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Akselerometer (G): X=${String.format("%.2f", imu.accelXG)} Y=${String.format("%.2f", imu.accelYG)} Z=${String.format("%.2f", imu.accelZG)} | Kalibrasi: ${if (imu.isCalibrated) "SELESAI" else "BELUM"}", color = Color.Gray, fontSize = 11.sp)
                    }
                }

                // Barometer Card
                item {
                    SensorCard(
                        title = "BAROMETER (DPS310 / BMP280)",
                        isHealthy = sensorHealth.baroHealthy,
                        isDetected = sensorHealth.baroDetected
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Ketinggian Relatif: ${String.format("%.2f m", baro.altitudeMeters)}", color = Color.White, fontSize = 12.sp)
                            Text("Kecepatan Vertikal: ${String.format("%.2f m/s", baro.verticalSpeedMs)}", color = NexendCyanPrimary, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Tekanan: ${String.format("%.2f hPa", baro.pressureHpa)} | Suhu: ${String.format("%.1f °C", baro.temperatureCelsius)}", color = Color.Gray, fontSize = 11.sp)
                    }
                }

                // GPS Card
                item {
                    SensorCard(
                        title = "GPS & KOMPAS (M10Q / NEO-M8N)",
                        isHealthy = sensorHealth.gpsHealthy,
                        isDetected = sensorHealth.gpsDetected
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Satelit: ${gps.satellites} (${gps.fixType})", color = if (gps.satellites >= 6) AviationGreen else Color(0xFFFFB300), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("Jarak ke Titik Pulang: ${String.format("%.1f m", gps.distanceToHomeMeters)}", color = Color.White, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Koordinat: ${String.format("%.6f, %.6f", gps.latitude, gps.longitude)} | HDOP: ${String.format("%.2f", gps.hdop)}", color = Color.Gray, fontSize = 11.sp)
                    }
                }

                // ToF & Optical Flow
                item {
                    SensorCard(
                        title = "RANGEFINDER LASER ToF & OPTICAL FLOW",
                        isHealthy = sensorHealth.tofHealthy,
                        isDetected = sensorHealth.tofDetected
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Jarak Permukaan (ToF): ${if (tof.isOutOfRange) "> 4.0 m (Out of Range)" else "${tof.distanceCm} cm"}", color = Color.White, fontSize = 12.sp)
                            Text("Kualitas Permukaan Optik: ${opticalFlow.surfaceQuality} %", color = Color.LightGray, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SensorCard(
    title: String,
    isHealthy: Boolean,
    isDetected: Boolean,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = NexendCardSurface),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(if (isHealthy) AviationGreen else AviationRed, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isHealthy) "HEALTHY" else if (isDetected) "ERROR" else "NOT DETECTED",
                        color = if (isHealthy) AviationGreen else AviationRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}
