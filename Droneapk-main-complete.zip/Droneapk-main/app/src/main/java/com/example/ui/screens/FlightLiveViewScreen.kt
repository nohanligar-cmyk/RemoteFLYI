package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ArmingState
import com.example.repository.DroneSystemState
import com.example.ui.components.BannerType
import com.example.ui.components.FpvVideoView
import com.example.ui.components.SafetyArmingDialog
import com.example.ui.components.TopBarAlertBanner
import com.example.ui.theme.AviationGreen
import com.example.ui.theme.AviationRed
import com.example.ui.theme.NexendCyanPrimary

@Composable
fun FlightLiveViewScreen(
    state: DroneSystemState,
    onNavigateHome: () -> Unit,
    onToggleArm: () -> Unit,
    onOpenDeviceCenter: () -> Unit,
    onOpenRemoteCenter: () -> Unit,
    onOpenFcCenter: () -> Unit,
    onOpenSensorCenter: () -> Unit,
    onOpenPidConfig: () -> Unit,
    onOpenDiagnostics: () -> Unit,
    onOpenSettings: () -> Unit,
    onShowToast: (String) -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    var isRecording by remember { mutableStateOf(false) }
    var showArmDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 1. FPV Video Viewport (Background)
        FpvVideoView(
            isSimulation = state.isSimulationMode,
            videoStats = state.videoStats,
            imuTelemetry = state.imu,
            modifier = Modifier.fillMaxSize()
        )

        // 2. TOP OSD BAR (Matching Screenshot 2)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Home button, Flight Mode ("N/A" or "P-GPS"), Alert Banner ("Remote tidak terhubung")
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Home Button
                IconButton(
                    onClick = onNavigateHome,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "Home",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Flight Mode (N/A, P-GPS, etc.)
                Text(
                    text = if (state.isSimulationMode) "P-GPS" else state.fcStatus.flightMode.displayName,
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                // Warning Banner
                val alertText = when {
                    !state.rcTelemetry.isConnected && !state.isSimulationMode -> "Remote tidak terhubung"
                    !state.fcStatus.isConnected && !state.isSimulationMode -> "Remote terhubung • Drone (FC) belum terhubung"
                    state.battery.isLowBattery -> "Baterai Rendah! Segera Mendarat"
                    state.isSimulationMode -> "MODE SIMULASI AKTIF • RP2040 VIRTUAL"
                    else -> "Siap Terbang (GPS)"
                }
                val bannerType = when {
                    !state.rcTelemetry.isConnected && !state.isSimulationMode -> BannerType.ERROR
                    !state.fcStatus.isConnected && !state.isSimulationMode -> BannerType.ERROR
                    state.battery.isLowBattery -> BannerType.WARNING
                    state.isSimulationMode -> BannerType.INFO
                    else -> BannerType.SUCCESS
                }

                TopBarAlertBanner(
                    text = alertText,
                    type = bannerType,
                    onClick = {
                        if (!state.rcTelemetry.isConnected) onOpenRemoteCenter()
                        else if (!state.fcStatus.isConnected) onOpenFcCenter()
                        else onOpenDiagnostics()
                    }
                )
            }

            // Right: Battery + Estimated Time, RC icon, Satellite icon, Three dots menu
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Battery & Flight Time
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (state.battery.isValid) "${state.battery.remainingPercent}%" else "--",
                        color = if (state.battery.isLowBattery) AviationRed else Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (state.battery.isValid) "${state.battery.estimatedFlightMinutes}'00\"" else "--'--\"",
                        color = Color.LightGray,
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // RC Icon (red when disconnected, green when connected)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "RC",
                        color = if (state.rcTelemetry.isConnected) AviationGreen else AviationRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Aircraft / Satellite Icon (red with 0 when disconnected, green with count when connected)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onOpenSensorCenter() }
                ) {
                    Icon(
                        imageVector = Icons.Default.Flight,
                        contentDescription = "Satelit",
                        tint = if (state.gps.satellites >= 6) AviationGreen else AviationRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${state.gps.satellites}",
                        color = if (state.gps.satellites >= 6) AviationGreen else AviationRed,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Three Dots Menu Button
                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreHoriz,
                            contentDescription = "Pengaturan",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(Color(0xFF1B232E))
                    ) {
                        DropdownMenuItem(
                            text = { Text("Pusat Perangkat USB", color = Color.White) },
                            onClick = { showMenu = false; onOpenDeviceCenter() }
                        )
                        DropdownMenuItem(
                            text = { Text("Pusat Remote (RP2040)", color = Color.White) },
                            onClick = { showMenu = false; onOpenRemoteCenter() }
                        )
                        DropdownMenuItem(
                            text = { Text("Drone / Flight Controller", color = Color.White) },
                            onClick = { showMenu = false; onOpenFcCenter() }
                        )
                        DropdownMenuItem(
                            text = { Text("Sensor & Diagnostik", color = Color.White) },
                            onClick = { showMenu = false; onOpenSensorCenter() }
                        )
                        DropdownMenuItem(
                            text = { Text("Tuning PID", color = Color.White) },
                            onClick = { showMenu = false; onOpenPidConfig() }
                        )
                        DropdownMenuItem(
                            text = { Text("Log Penerbangan", color = Color.White) },
                            onClick = { showMenu = false; onOpenDiagnostics() }
                        )
                        DropdownMenuItem(
                            text = { Text("Pengaturan", color = Color.White) },
                            onClick = { showMenu = false; onOpenSettings() }
                        )
                    }
                }
            }
        }

        // 3. LEFT ACTION BUTTON: Takeoff / RTH Button (circle with arrow up icon)
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 20.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0x66000000))
                    .border(1.5.dp, Color(0x66FFFFFF), CircleShape)
                    .clickable { showArmDialog = true },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowUpward,
                    contentDescription = "Takeoff / Arm",
                    tint = if (state.fcStatus.armingState == ArmingState.ARMED) AviationRed else Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // 4. BOTTOM LEFT TELEMETRY OSD (Matching Screenshot 2)
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .navigationBarsPadding()
                .padding(start = 24.dp, bottom = 18.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // H (Altitude)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "H",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (state.baro.isValid) String.format("%.1f m", state.baro.altitudeMeters) else "- - m",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = if (state.baro.isValid) String.format("%.1f m/s", state.baro.verticalSpeedMs) else "- - m/s",
                    color = Color(0xFFB0BEC5),
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // D (Distance)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "D",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (state.gps.isValid) String.format("%.1f m", state.gps.distanceToHomeMeters) else "- - m",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(16.dp))
                Text(
                    text = if (state.fcStatus.isConnected) String.format("%.1f m/s", state.fcStatus.horizontalSpeedMs) else "- - m/s",
                    color = Color(0xFFB0BEC5),
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        // 5. RIGHT CONTROLS: Shutter Button, Mode Switch, Gallery (Matching Screenshot 2)
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Mode switcher (photo/video)
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0x66000000))
                    .clickable { onShowToast("Mode Kamera: FPV DVR 720p 60fps") },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Videocam,
                    contentDescription = "Mode",
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Shutter Button: Large white circle with outer ring
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(Color.Transparent)
                    .border(3.dp, Color.White, CircleShape)
                    .clickable {
                        isRecording = !isRecording
                        onShowToast(if (isRecording) "Perekaman DVR FPV dimulai" else "Perekaman DVR FPV disimpan ke galeri")
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(if (isRecording) 24.dp else 44.dp)
                        .clip(if (isRecording) RoundedCornerShape(4.dp) else CircleShape)
                        .background(if (isRecording) AviationRed else Color.White)
                )
            }

            // Playback shortcut
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0x66000000))
                    .clickable { onShowToast("Membuka Pemutar Rekaman FPV") },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Playback",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // 6. BOTTOM RIGHT CAMERA PARAMETERS BADGE (Matching Screenshot 2: S N/A, F N/A, ISO N/A, MM N/A, PRO)
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(end = 24.dp, bottom = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ParamTag("S", "N/A")
                    ParamTag("F", "N/A")
                }
                Spacer(modifier = Modifier.height(2.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ParamTag("ISO", "N/A")
                    ParamTag("MM", "N/A")
                }
            }

            // PRO Badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(3.dp))
                    .background(Color(0x80333333))
                    .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(3.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "PRO",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    if (showArmDialog) {
        SafetyArmingDialog(
            isArmed = state.fcStatus.armingState == ArmingState.ARMED,
            isSimulation = state.isSimulationMode,
            onConfirm = {
                showArmDialog = false
                onToggleArm()
            },
            onDismiss = { showArmDialog = false }
        )
    }
}

@Composable
private fun ParamTag(key: String, value: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(key, color = Color(0xFF90A4AE), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.width(3.dp))
        Text(value, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
    }
}
