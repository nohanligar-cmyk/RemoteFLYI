package com.example.protocol

import java.nio.ByteBuffer
import java.nio.ByteOrder

object NexendProtocol {
    const val SYNC_1: Byte = 0xAA.toByte()
    const val SYNC_2: Byte = 0x55.toByte()

    const val MSG_HELLO: Byte = 0x01
    const val MSG_HEARTBEAT: Byte = 0x02
    const val MSG_TELEMETRY: Byte = 0x10
    const val MSG_IMU: Byte = 0x11
    const val MSG_BARO: Byte = 0x12
    const val MSG_GPS: Byte = 0x13
    const val MSG_BATTERY: Byte = 0x14
    const val MSG_SENSOR_HEALTH: Byte = 0x15
    const val MSG_RC_CHANNELS: Byte = 0x20
    const val MSG_PID_READ_REQ: Byte = 0x30
    const val MSG_PID_DATA: Byte = 0x31
    const val MSG_PID_WRITE_REQ: Byte = 0x32
    const val MSG_PID_WRITE_ACK: Byte = 0x33
    const val MSG_COMMAND_REQ: Byte = 0x40
    const val MSG_COMMAND_ACK: Byte = 0x41

    /**
     * Computes CRC16-CCITT (poly 0x1021, init 0xFFFF)
     */
    fun calculateCrc16(bytes: ByteArray, offset: Int = 0, length: Int = bytes.size): Int {
        var crc = 0xFFFF
        for (i in offset until (offset + length)) {
            val b = bytes[i].toInt() and 0xFF
            crc = crc xor (b shl 8)
            for (j in 0 until 8) {
                crc = if ((crc and 0x8000) != 0) {
                    (crc shl 1) xor 0x1021
                } else {
                    crc shl 1
                }
                crc = crc and 0xFFFF
            }
        }
        return crc
    }

    /**
     * Builds a framed packet with header, seq, length, payload, and CRC16
     */
    fun buildPacket(msgId: Byte, seq: Byte, payload: ByteArray): ByteArray {
        val payloadLen = payload.size.coerceAtMost(255)
        val packet = ByteArray(2 + 1 + 1 + 1 + payloadLen + 2)
        packet[0] = SYNC_1
        packet[1] = SYNC_2
        packet[2] = msgId
        packet[3] = seq
        packet[4] = payloadLen.toByte()

        System.arraycopy(payload, 0, packet, 5, payloadLen)

        // CRC calculated over msgId, seq, length, and payload
        val crc = calculateCrc16(packet, 2, 3 + payloadLen)
        packet[5 + payloadLen] = ((crc shr 8) and 0xFF).toByte()
        packet[6 + payloadLen] = (crc and 0xFF).toByte()

        return packet
    }
}

data class NexendPacket(
    val msgId: Byte,
    val sequence: Int,
    val payload: ByteArray,
    val timestampMs: Long = System.currentTimeMillis()
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as NexendPacket
        return msgId == other.msgId && sequence == other.sequence && payload.contentEquals(other.payload)
    }

    override fun hashCode(): Int {
        var result = msgId.toInt()
        result = 31 * result + sequence
        result = 31 * result + payload.contentHashCode()
        return result
    }
}
